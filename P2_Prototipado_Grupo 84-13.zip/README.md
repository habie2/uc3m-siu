# Integrantes del Grupo

Sonia Navas Rutete 100472180

David Sánchez Arranz 100460314

Javier Sanz Díaz 100472296

# Ki..ller App

Este proyecto sincroniza un Kindle con una control remoto en el móvil.

## Cómo iniciar

1. Asegúrate de tener Node.js instalado.
2. Ejecuta el servidor:

```bash
node server.js
```

3. La interfaz kindle se encontrará en https://localhost:3000/kindle/ y la interfaz del móvil en https://localhost:3000/phone/
